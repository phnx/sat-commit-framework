def test_util():
    print("ok")
