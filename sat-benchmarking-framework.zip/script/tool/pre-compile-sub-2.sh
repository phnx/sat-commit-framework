# !/bin/bash


# [autoreconf -fi, autogen.sh] && ./configure && make

echo "start configure"
bash configure